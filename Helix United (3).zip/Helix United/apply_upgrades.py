import re
import os

file_path = 'e:/Helix United/Helix United website.html'

with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
    content = f.read()

# 1. Add Responsive CSS
css_injection = """
        /* ════════════════════════ RESPONSIVE ════════════════════════ */
        @media (max-width: 1024px) {
            .container { padding: 0 20px; }
            .grid-4 { grid-template-columns: repeat(2, 1fr); }
            .grid-3 { grid-template-columns: repeat(2, 1fr); }
            .about-grid { grid-template-columns: 1fr; gap: 40px; }
            .contact-grid { grid-template-columns: 1fr; gap: 40px; }
        }
        @media (max-width: 768px) {
            .nav-links, .nav-actions { display: none !important; }
            .mobile-menu-btn { display: flex; }
            .hero-title { font-size: 64px; line-height: 0.9; }
            .grid-4, .grid-3, .grid-2 { grid-template-columns: 1fr; }
            .footer-grid { grid-template-columns: 1fr; gap: 32px; }
            .match-teams { flex-direction: column; gap: 16px; }
            .match-score-box { margin: 16px 0; }
            .news-card-img-placeholder { display: none; }
            .admin-sidebar { display: none; }
            .admin-main { margin-left: 0; }
            .flip-player-card { width: 100%; }
        }
        @media (max-width: 480px) {
            .hero-title { font-size: 48px; }
            .text-5xl { font-size: 36px; }
            .text-4xl { font-size: 28px; }
            .fc-front-top .fc-number { font-size: 40px; }
            .fc-front-top .fc-avatar { width: 64px; height: 64px; font-size: 24px; }
            .stat-bar-label span { font-size: 11px; }
            .reg-step-label { display: none; }
            .admin-login-img { width: 60px; height: 60px; }
        }
    </style>
"""
if "/* ════════════════════════ RESPONSIVE ════════════════════════ */" not in content:
    content = content.replace("    </style>", css_injection)


# 2. Redesign Admin Panel
old_admin_html = """<div id="admin-login"
            style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px">
            <div
                style="background:var(--card);border:1px solid var(--border);border-radius:var(--radius-lg);padding:48px;width:100%;max-width:440px">
                <div class="text-center mb-8">
                    <img src="helix united team logo.png" alt="Helix United Logo" class="admin-login-img"
                        onerror="this.outerHTML=`<div class='nav-logo-emblem' style='margin:0 auto 16px;width:56px;height:56px;font-size:28px'>H</div>`">
                    <h2 class="display text-4xl">Admin <span class="text-yellow">Panel</span></h2>
                    <p style="color:var(--gray);font-size:14px;margin-top:6px">Helix United FC — Secure Access</p>
                </div>
                <div style="display:flex;flex-direction:column;gap:16px">
                    <div class="input-group">
                        <label class="input-label">Username</label>
                        <input class="input" id="admin-user" placeholder="Helixunited" value="Helixunited">
                    </div>
                    <div class="input-group">
                        <label class="input-label">Password</label>
                        <input class="input" type="password" id="admin-pass" placeholder="HU@2019" value="HU@2019"
                            onkeydown="if(event.key==='Enter')doAdminLogin()">
                    </div>
                    <button class="btn btn-primary w-full" onclick="doAdminLogin()">Login to Admin</button>
                    <button class="btn btn-ghost w-full" onclick="closeAdminPanel()">← Back to Website</button>
                </div>
            </div>
        </div>"""

new_admin_html = """<div id="admin-login"
            style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;background:var(--black);position:relative;overflow:hidden">
            <!-- Modern background accents -->
            <div style="position:absolute;top:-10%;left:-10%;width:40vw;height:40vw;background:var(--yellow);filter:blur(150px);opacity:0.05;border-radius:50%;pointer-events:none"></div>
            <div style="position:absolute;bottom:-10%;right:-10%;width:30vw;height:30vw;background:var(--yellow);filter:blur(120px);opacity:0.05;border-radius:50%;pointer-events:none"></div>
            
            <div class="card card-hover"
                style="background:rgba(26,28,31,0.8);backdrop-filter:blur(24px);border:1px solid rgba(255,255,255,0.05);border-radius:24px;padding:48px 40px;width:100%;max-width:440px;position:relative;z-index:10;box-shadow:0 24px 64px rgba(0,0,0,0.6)">
                <div class="text-center mb-8">
                    <img src="helix united team logo.png" alt="Helix United Logo" class="admin-login-img"
                        onerror="this.outerHTML=`<div class='nav-logo-emblem' style='margin:0 auto 16px;width:64px;height:64px;font-size:32px;box-shadow:0 0 20px rgba(245,197,24,0.3)'>H</div>`" style="width:80px;height:80px;margin-bottom:20px;border-radius:50%;padding:4px;border:2px solid rgba(245,197,24,0.2)">
                    <h2 class="display text-4xl" style="letter-spacing:1px">Admin <span class="text-yellow">Panel</span></h2>
                    <p style="color:var(--gray-mid);font-size:14px;margin-top:8px;font-weight:500">Helix United FC Secure Access</p>
                </div>
                <div style="display:flex;flex-direction:column;gap:20px">
                    <div class="input-group">
                        <label class="input-label" style="font-size:11px">Username</label>
                        <input class="input" id="admin-user" placeholder="Enter username" value="Helixunited" style="padding:14px;background:rgba(20,21,23,0.8);border-color:rgba(255,255,255,0.1)">
                        <div class="input-err-msg hidden" id="err-admin-user"></div>
                    </div>
                    <div class="input-group" style="position:relative">
                        <div style="display:flex;justify-content:space-between;align-items:center">
                            <label class="input-label" style="font-size:11px">Password</label>
                            <span onclick="togglePassword()" style="font-size:12px;color:var(--yellow);cursor:pointer;font-weight:600">Show</span>
                        </div>
                        <input class="input" type="password" id="admin-pass" placeholder="Enter password" value="HU@2019"
                            onkeydown="if(event.key==='Enter')doAdminLoginWithUI()" style="padding:14px;background:rgba(20,21,23,0.8);border-color:rgba(255,255,255,0.1)">
                        <div class="input-err-msg hidden" id="err-admin-pass"></div>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                        <input type="checkbox" id="admin-remember" style="accent-color:var(--yellow);width:16px;height:16px;cursor:pointer">
                        <label for="admin-remember" style="font-size:13px;color:var(--gray);cursor:pointer">Remember me for 30 days</label>
                    </div>
                    <button class="btn btn-primary w-full" id="admin-login-btn" onclick="doAdminLoginWithUI()" style="padding:16px;font-size:14px;letter-spacing:1px;border-radius:12px">
                        <span id="admin-login-text">Login to Dashboard</span>
                        <svg id="admin-login-loader" class="hidden" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="animation:spin 1s linear infinite"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                    </button>
                    <button class="btn btn-ghost w-full" onclick="closeAdminPanel()" style="padding:12px;font-size:13px">← Back to Website</button>
                </div>
            </div>
        </div>"""

if new_admin_html not in content:
    content = content.replace(old_admin_html, new_admin_html)

# 3. Add scripts for Toggle Password, Admin Login UI, and Registration mock email
js_injection = """
        function togglePassword() {
            const pass = document.getElementById('admin-pass');
            if (pass.type === 'password') {
                pass.type = 'text';
                event.target.textContent = 'Hide';
            } else {
                pass.type = 'password';
                event.target.textContent = 'Show';
            }
        }

        function doAdminLoginWithUI() {
            const u = document.getElementById('admin-user').value;
            const p = document.getElementById('admin-pass').value;
            const btn = document.getElementById('admin-login-btn');
            const txt = document.getElementById('admin-login-text');
            const loader = document.getElementById('admin-login-loader');
            
            // Show loading state
            if(btn) {
                btn.style.opacity = '0.8';
                btn.style.pointerEvents = 'none';
            }
            if (txt) txt.style.display = 'none';
            if (loader) loader.classList.remove('hidden');

            setTimeout(() => {
                // Reset loading state
                if(btn) {
                    btn.style.opacity = '1';
                    btn.style.pointerEvents = 'auto';
                }
                if (txt) txt.style.display = 'block';
                if (loader) loader.classList.add('hidden');

                if (u === 'Helixunited' && p === 'HU@2019') {
                    doAdminLogin();
                    showToast('Login successful', 'success');
                } else {
                    const errPass = document.getElementById('err-admin-pass');
                    if (errPass) {
                        errPass.textContent = 'Invalid credentials';
                        errPass.classList.remove('hidden');
                    }
                }
            }, 1200); // Simulate network request
        }
        
        let uploadedPhotoBase64 = null;
        const originalPreviewPhoto = previewPhoto;
        previewPhoto = function(input) {
            originalPreviewPhoto(input);
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = e => {
                    uploadedPhotoBase64 = e.target.result;
                };
                reader.readAsDataURL(input.files[0]);
            }
        };

        const originalSubmitRegistration = submitRegistration;
        submitRegistration = function() {
            // Validate all
            const agrees = document.getElementById('reg-agree')?.checked;
            if (!agrees) {
                document.getElementById('err-agree').textContent = 'You must agree to the terms';
                return;
            }
            // Show success, simulate email
            document.getElementById('reg-form-wrap').classList.add('hidden');
            document.getElementById('reg-progress').classList.add('hidden');
            document.getElementById('reg-success').classList.remove('hidden');
            
            // Mock send email
            setTimeout(() => {
                showToast('Registration confirmation email sent!', 'success');
            }, 1500);
            
            // Mock save to DB (we just add a fake player object for demonstration)
            if (uploadedPhotoBase64) {
               console.log("Photo uploaded and saved to DB!");
            }
        };
        
        // Add spin animation CSS dynamically
        const style = document.createElement('style');
        style.textContent = '@keyframes spin { 100% { transform: rotate(360deg); } }';
        document.head.appendChild(style);
"""
if "function togglePassword()" not in content:
    content = content.replace("</script>", js_injection + "\n    </script>")

# 4. Modify Player card to show photo
player_avatar_old = """<div class="fc-avatar">${initials}</div>"""
player_avatar_new = """<div class="fc-avatar">${p.photo ? `<img src="${p.photo}" style="width:100%;height:100%;object-fit:cover;border-radius:50%">` : initials}</div>"""
content = content.replace(player_avatar_old, player_avatar_new)

# Modify player detail modal to show photo
modal_avatar_old = """<div class="player-card-avatar" style="width:80px;height:80px;font-size:30px">${initials}</div>"""
modal_avatar_new = """<div class="player-card-avatar" style="width:80px;height:80px;font-size:30px;padding:0;overflow:hidden">${p.photo ? `<img src="${p.photo}" style="width:100%;height:100%;object-fit:cover">` : initials}</div>"""
content = content.replace(modal_avatar_old, modal_avatar_new)

# Optional: Add a fake photo to one of the players to demonstrate the UI works
if 'photo:' not in content:
    content = content.replace("name: 'Alvi Rahman', position: 'Forward'", "name: 'Alvi Rahman', position: 'Forward', photo: 'helix_cover_photo.jpg'")


with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Upgrades applied successfully.")

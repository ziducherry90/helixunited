const fs = require('fs');
const lines = fs.readFileSync('Helix United website.html', 'utf8').split('\n');
lines.forEach((line, i) => {
    if (line.includes('sliders') || line.includes('slider') || line.includes('DB.slider')) {
        console.log(`Line ${i+1}: ${line.trim()}`);
    }
});

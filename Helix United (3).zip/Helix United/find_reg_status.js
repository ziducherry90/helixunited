const fs = require('fs');
const lines = fs.readFileSync('Helix United website.html', 'utf8').split('\n');
lines.forEach((line, i) => {
    if (line.includes('setRegStatus') || line.includes('Status') || line.includes('Approve') || line.includes('Reject')) {
        if (line.includes('function') || line.includes('onclick')) {
            console.log(`Line ${i+1}: ${line.trim()}`);
        }
    }
});

import re
import sys

file_path = "e:/Helix United/Helix United website.html"
with open(file_path, "r", encoding="utf-8") as f:
    text = f.read()

old_submit = """        const originalSubmitRegistration = submitRegistration;
        submitRegistration = function() {
            const agrees = document.getElementById('reg-agree')?.checked;
            if (!agrees) {
                document.getElementById('err-agree').textContent = 'You must agree to the terms';
                return;
            }
            
            const p1 = document.getElementById('reg-pass')?.value;
            const p2 = document.getElementById('reg-pass-confirm')?.value;
            if (p1 && p1 !== p2) {
                const err = document.getElementById('err-pass-confirm');
                if(err) { err.textContent = 'Passwords do not match'; err.classList.remove('hidden'); }
                return;
            }
            
            document.getElementById('reg-form-wrap').classList.add('hidden');
            document.getElementById('reg-progress').classList.add('hidden');
            document.getElementById('reg-success').classList.remove('hidden');
            
            setTimeout(() => { showToast('Registration confirmation email sent!', 'success'); }, 1500);
        };"""

new_submit = """        const originalSubmitRegistration = submitRegistration;
        submitRegistration = async function() {
            const agrees = document.getElementById('reg-agree')?.checked;
            if (!agrees) {
                document.getElementById('err-agree').textContent = 'You must agree to the terms';
                return;
            }
            
            const p1 = document.getElementById('reg-pass')?.value;
            const p2 = document.getElementById('reg-pass-confirm')?.value;
            if (p1 && p1 !== p2) {
                const err = document.getElementById('err-pass-confirm');
                if(err) { err.textContent = 'Passwords do not match'; err.classList.remove('hidden'); }
                return;
            }

            // Gather info for email
            const name = document.getElementById('reg-name')?.value || 'New Player';
            const email = document.getElementById('reg-email')?.value || '';
            const phone = document.getElementById('reg-phone')?.value || '';
            const category = document.getElementById('reg-category')?.value || '';
            const position = document.getElementById('reg-position')?.value || '';

            // Show a loading toast
            showToast('Sending registration data...', 'info');

            try {
                const response = await fetch('/api/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, email, phone, category, position })
                });
                
                if (response.ok) {
                    document.getElementById('reg-form-wrap').classList.add('hidden');
                    document.getElementById('reg-progress').classList.add('hidden');
                    document.getElementById('reg-success').classList.remove('hidden');
                    showToast('Registration confirmation email sent successfully!', 'success');
                } else {
                    showToast('Error: Failed to send email via backend.', 'error');
                }
            } catch (err) {
                console.error(err);
                showToast('Network Error: Could not connect to backend server.', 'error');
                // Fallback for static viewing without server
                document.getElementById('reg-form-wrap').classList.add('hidden');
                document.getElementById('reg-progress').classList.add('hidden');
                document.getElementById('reg-success').classList.remove('hidden');
            }
        };"""

if old_submit in text:
    text = text.replace(old_submit, new_submit)
else:
    print("Warning: old_submit block not found.")

with open(file_path, "w", encoding="utf-8") as f:
    f.write(text)

print("Updated submitRegistration for fetch.")

require('dotenv').config();
const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const REGISTRATIONS_FILE = path.join(__dirname, 'registrations.json');


const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' })); // Support base64 image uploads

// Serve the static files from the current directory
app.use(express.static(__dirname));

// Ensure email transporter configuration exists, otherwise fallback to ethereal
async function getTransporter() {
    if (process.env.SMTP_HOST && process.env.SMTP_USER) {
        return nodemailer.createTransport({
            host: process.env.SMTP_HOST,
            port: process.env.SMTP_PORT || 587,
            secure: process.env.SMTP_SECURE === 'true',
            auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS
            }
        });
    }

    // Fallback: Generate Ethereal Email account
    console.log("No SMTP credentials found in .env. Generating Ethereal test account...");
    const testAccount = await nodemailer.createTestAccount();
    return nodemailer.createTransport({
        host: "smtp.ethereal.email",
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
            user: testAccount.user, // generated ethereal user
            pass: testAccount.pass, // generated ethereal password
        },
    });
}

app.post('/api/register', async (req, res) => {
    try {
        const {
            name,
            dob,
            gender,
            address,
            phone,
            email,
            emergencyName,
            emergencyPhone,
            category,
            position,
            experience,
            notes,
            photo
        } = req.body;
        
        if (!name || !email) {
            return res.status(400).json({ error: 'Name and email are required.' });
        }

        // Save registration data to registrations.json file
        let registrations = [];
        if (fs.existsSync(REGISTRATIONS_FILE)) {
            try {
                const data = fs.readFileSync(REGISTRATIONS_FILE, 'utf8');
                registrations = JSON.parse(data || '[]');
            } catch (err) {
                console.error("Error reading registrations.json, starting fresh:", err);
            }
        }
        
        const newReg = {
            id: Date.now(),
            name,
            dob: dob || '',
            gender: gender || '',
            address: address || '',
            phone: phone || '',
            email,
            emergencyName: emergencyName || '',
            emergencyPhone: emergencyPhone || '',
            category: category || '',
            position: position || '',
            experience: experience || '',
            notes: notes || '',
            date: new Date().toISOString().split('T')[0],
            status: 'Pending',
            photo: photo || null
        };
        
        registrations.push(newReg);
        fs.writeFileSync(REGISTRATIONS_FILE, JSON.stringify(registrations, null, 2), 'utf8');
        console.log(`Registration saved for ${name} in registrations.json`);

        const htmlEmail = `
        <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #1a1c1f; border-radius: 16px; overflow: hidden; color: #ffffff;">
            <div style="background-color: #f5c518; padding: 30px; text-align: center;">
                <h1 style="color: #000000; margin: 0; font-size: 28px; text-transform: uppercase; letter-spacing: 1px;">Welcome to the Yellow Army!</h1>
            </div>
            <div style="padding: 40px 30px;">
                <h2 style="margin-top: 0; color: #f5c518;">Hello ${name},</h2>
                <p style="font-size: 16px; line-height: 1.6; color: #cccccc;">
                    Your registration for the Helix United FC Academy has been successfully received. We are thrilled to have you join us!
                </p>
                <div style="background-color: rgba(255,255,255,0.05); border-left: 4px solid #f5c518; padding: 15px 20px; margin: 25px 0; border-radius: 4px;">
                    <h3 style="margin-top: 0; color: #ffffff; font-size: 14px; text-transform: uppercase;">Registration Details</h3>
                    <ul style="list-style: none; padding: 0; margin: 0; color: #aaaaaa; font-size: 15px; line-height: 1.8;">
                        <li><strong style="color:#ffffff;">Category:</strong> ${category || 'N/A'}</li>
                        <li><strong style="color:#ffffff;">Position:</strong> ${position || 'N/A'}</li>
                        <li><strong style="color:#ffffff;">Phone:</strong> ${phone || 'N/A'}</li>
                    </ul>
                </div>
                <p style="font-size: 16px; line-height: 1.6; color: #cccccc;">
                    Our coaching staff will review your details and get in touch within 3-5 business days regarding the next steps and tryout schedules.
                </p>
                <div style="text-align: center; margin-top: 40px;">
                    <a href="https://helixunited.com" style="background-color: #f5c518; color: #000000; padding: 14px 28px; text-decoration: none; font-weight: bold; border-radius: 8px; font-size: 16px;">Visit Dashboard</a>
                </div>
            </div>
            <div style="background-color: #111111; padding: 20px; text-align: center; color: #666666; font-size: 12px;">
                &copy; ${new Date().getFullYear()} Helix United Football Club. All rights reserved.
            </div>
        </div>
        `;

        let emailSent = false;
        let messageId = null;
        try {
            const transporter = await getTransporter();
            const info = await transporter.sendMail({
                from: `"Helix United FC" <${process.env.SMTP_USER || 'noreply@helixunited.com'}>`,
                to: email,
                subject: "Registration Confirmed - Helix United FC",
                text: `Welcome ${name}! Your registration was successful.`,
                html: htmlEmail,
            });

            console.log("Message sent: %s", info.messageId);
            messageId = info.messageId;
            emailSent = true;
            
            // If using Ethereal, log the preview URL
            if (info.messageId && info.messageId.includes('@ethereal.email')) {
                console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
            }
        } catch (mailError) {
            console.error("Failed to send registration confirmation email:", mailError.message);
        }

        res.status(200).json({ success: true, emailSent, messageId, registration: newReg });
    } catch (error) {
        console.error("Error during registration:", error);
        res.status(500).json({ error: 'Failed to process registration' });
    }
});

app.get('/api/registrations', (req, res) => {
    try {
        let registrations = [];
        if (fs.existsSync(REGISTRATIONS_FILE)) {
            const data = fs.readFileSync(REGISTRATIONS_FILE, 'utf8');
            registrations = JSON.parse(data || '[]');
        }
        res.status(200).json(registrations);
    } catch (error) {
        console.error("Error reading registrations:", error);
        res.status(500).json({ error: 'Failed to retrieve registrations' });
    }
});

app.post('/api/registrations/status', (req, res) => {
    try {
        const { id, status } = req.body;
        if (!id || !status) {
            return res.status(400).json({ error: 'Missing id or status' });
        }
        
        let registrations = [];
        if (fs.existsSync(REGISTRATIONS_FILE)) {
            const data = fs.readFileSync(REGISTRATIONS_FILE, 'utf8');
            registrations = JSON.parse(data || '[]');
        }
        
        const reg = registrations.find(r => r.id === parseInt(id) || r.id === id);
        if (reg) {
            reg.status = status;
            fs.writeFileSync(REGISTRATIONS_FILE, JSON.stringify(registrations, null, 2), 'utf8');
            console.log(`Updated registration status for ID ${id} to ${status}`);
            return res.status(200).json({ success: true, registration: reg });
        } else {
            return res.status(404).json({ error: 'Registration not found' });
        }
    } catch (error) {
        console.error("Error updating registration status:", error);
        res.status(500).json({ error: 'Failed to update registration status' });
    }
});

// Fallback to serve the main HTML file for the root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'Helix United website.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});

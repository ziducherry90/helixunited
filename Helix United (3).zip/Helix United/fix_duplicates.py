import re

file_path = "e:/Helix United/Helix United website.html"
with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
    text = f.read()

# 1. Clean up duplicate togglePassword injections.
# We'll regex out all chunks starting with "function togglePassword()" up to "document.head.appendChild(style);"
text = re.sub(r'\s*function togglePassword\(\) \{.*?document\.head\.appendChild\(style\);\n', '', text, flags=re.DOTALL)

# Now inject it exactly ONCE before the last </script>
last_script_idx = text.rfind('</script>')
if last_script_idx != -1:
    text = text[:last_script_idx] + """
        function togglePassword() {
            const pass = document.getElementById('admin-pass');
            if (pass.type === 'password') {
                pass.type = 'text';
                event.target.textContent = 'Hide';
            } else {
                pass.type = 'password';
                event.target.textContent = 'Show';
            }
        }

        function doAdminLoginWithUI() {
            const u = document.getElementById('admin-user').value;
            const p = document.getElementById('admin-pass').value;
            const btn = document.getElementById('admin-login-btn');
            const txt = document.getElementById('admin-login-text');
            const loader = document.getElementById('admin-login-loader');
            
            if(btn) { btn.style.opacity = '0.8'; btn.style.pointerEvents = 'none'; }
            if(txt) txt.style.display = 'none';
            if(loader) loader.classList.remove('hidden');

            setTimeout(() => {
                if(btn) { btn.style.opacity = '1'; btn.style.pointerEvents = 'auto'; }
                if(txt) txt.style.display = 'block';
                if(loader) loader.classList.add('hidden');

                if (u === 'Helixunited' && p === 'HU@2019') {
                    doAdminLogin();
                    showToast('Login successful', 'success');
                } else {
                    const errPass = document.getElementById('err-admin-pass');
                    if(errPass) { errPass.textContent = 'Invalid credentials'; errPass.classList.remove('hidden'); }
                }
            }, 1200);
        }
        
        let uploadedPhotoBase64 = null;
        const originalPreviewPhoto = previewPhoto;
        previewPhoto = function(input) {
            originalPreviewPhoto(input);
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = e => { uploadedPhotoBase64 = e.target.result; };
                reader.readAsDataURL(input.files[0]);
            }
        };

        function checkPasswordStrength() {
            const val = document.getElementById('reg-pass').value;
            const bar = document.getElementById('pass-strength-bar');
            const text = document.getElementById('pass-strength-text');
            let strength = 0;
            if(val.length > 5) strength++;
            if(val.length > 8) strength++;
            if(/[A-Z]/.test(val)) strength++;
            if(/[0-9]/.test(val)) strength++;
            
            if (strength === 0) { bar.style.width = '0'; text.textContent = ''; }
            else if (strength <= 2) { bar.style.width = '33%'; bar.style.background = 'var(--red)'; text.textContent = 'Weak'; text.style.color = 'var(--red)'; }
            else if (strength === 3) { bar.style.width = '66%'; bar.style.background = 'var(--yellow)'; text.textContent = 'Good'; text.style.color = 'var(--yellow)'; }
            else { bar.style.width = '100%'; bar.style.background = 'var(--green)'; text.textContent = 'Strong'; text.style.color = 'var(--green)'; }
        }

        const originalSubmitRegistration = submitRegistration;
        submitRegistration = function() {
            const agrees = document.getElementById('reg-agree')?.checked;
            if (!agrees) {
                document.getElementById('err-agree').textContent = 'You must agree to the terms';
                return;
            }
            
            const p1 = document.getElementById('reg-pass')?.value;
            const p2 = document.getElementById('reg-pass-confirm')?.value;
            if (p1 && p1 !== p2) {
                const err = document.getElementById('err-pass-confirm');
                if(err) { err.textContent = 'Passwords do not match'; err.classList.remove('hidden'); }
                return;
            }
            
            document.getElementById('reg-form-wrap').classList.add('hidden');
            document.getElementById('reg-progress').classList.add('hidden');
            document.getElementById('reg-success').classList.remove('hidden');
            
            setTimeout(() => { showToast('Registration confirmation email sent!', 'success'); }, 1500);
        };
        
        const style = document.createElement('style');
        style.textContent = '@keyframes spin { 100% { transform: rotate(360deg); } }';
        document.head.appendChild(style);
""" + text[last_script_idx:]

# Add Password fields to Registration Step 2
password_html = """
                                <div class="input-group">
                                    <label class="input-label">Password *</label>
                                    <input class="input" type="password" id="reg-pass" placeholder="Create a password" onkeyup="checkPasswordStrength()" required>
                                    <div style="height:4px;background:var(--border);border-radius:2px;margin-top:4px;overflow:hidden">
                                        <div id="pass-strength-bar" style="height:100%;width:0;transition:all 0.3s"></div>
                                    </div>
                                    <div id="pass-strength-text" style="font-size:11px;margin-top:2px"></div>
                                </div>
                                <div class="input-group">
                                    <label class="input-label">Confirm Password *</label>
                                    <input class="input" type="password" id="reg-pass-confirm" placeholder="Confirm your password" required>
                                    <div class="input-err-msg hidden" id="err-pass-confirm"></div>
                                </div>
"""

# Inject password_html before Emergency Contact Name if it doesn't already exist
if 'id="reg-pass"' not in text:
    text = text.replace(
        '<div class="input-group">\\n                                    <label class="input-label">Emergency Contact Name *</label>',
        password_html + '\\n                                <div class="input-group">\\n                                    <label class="input-label">Emergency Contact Name *</label>'
    )
    
    # Try alternate replacement for different newline/whitespace formatting
    text = re.sub(
        r'(<div class="input-group">\s*<label class="input-label">Emergency Contact Name)',
        password_html + r'\n\1',
        text
    )

with open(file_path, "w", encoding="utf-8") as f:
    f.write(text)

print("Duplicates cleaned and password field injected.")
